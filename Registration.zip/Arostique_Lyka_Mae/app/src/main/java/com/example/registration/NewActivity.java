package com.example.registration;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;


public class NewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new);
        TextView textView = findViewById(R.id.textView);
        Intent intent = getIntent();
        String fname = intent.getStringExtra("name");
        textView.setText("Welcome to Goole! " +fname+ "!");
        Toast.makeText(getApplicationContext(), "New Activity Launched!", Toast.LENGTH_SHORT).show();
    }
}